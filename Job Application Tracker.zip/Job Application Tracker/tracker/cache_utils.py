from django.core.cache import cache

from .models import JobApplication


CACHE_TIMEOUT = 60 * 5 


def get_applications_cache_key(user_id):
    return f"applications_user_{user_id}"


def get_dashboard_stats_cache_key(user_id):
    return f"dashboard_stats_user_{user_id}"


def invalidate_user_cache(user_id):
    cache.delete(
        get_applications_cache_key(user_id)
    )

    cache.delete(
        get_dashboard_stats_cache_key(user_id)
    )


def get_dashboard_stats(user_id):
    cache_key = get_dashboard_stats_cache_key(user_id)

    cached_stats = cache.get(cache_key)

    if cached_stats is not None:
        print("DASHBOARD STATS: CACHE HIT")
        return cached_stats

    print("DASHBOARD STATS: DATABASE HIT")

    applications = JobApplication.objects.filter(
        user_id=user_id
    )

    stats = {
        "total": applications.count(),
        "Applied": applications.filter(
            status="Applied"
        ).count(),
        "Screening": applications.filter(
            status="Screening"
        ).count(),
        "Interview": applications.filter(
            status="Interview"
        ).count(),
        "Offer": applications.filter(
            status="Offer"
        ).count(),
        "Rejected": applications.filter(
            status="Rejected"
        ).count(),
        "Withdrawn": applications.filter(
            status="Withdrawn"
        ).count(),
    }

    cache.set(
        cache_key,
        stats,
        CACHE_TIMEOUT
    )

    return stats