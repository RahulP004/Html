from django.contrib import admin
from .models import JobApplication,ApplicationStatusLog

@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display =('company_name','role','user','status','applied_date','created_at',)
    list_filter=('status','applied_date','created_at',)
    search_fields=('company_name','role','user__username')
    
    
@admin.register(ApplicationStatusLog)
class ApplicationStatusLogAdmin(admin.ModelAdmin):
    list_display=('application','old_status','new_status','changed_at',)
    list_filter=('old_status','new_status','changed_at',)
    search_fields=('application__comapny_name','application__role',)
    