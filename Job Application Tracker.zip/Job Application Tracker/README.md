# Job Application Tracker

Django-based Job Application Tracker with REST API, Token Authentication, Redis, and Celery.

## 1. Install Dependencies

Activate the virtual environment:

```powershell
.\venv\Scripts\Activate.ps1
```

Install dependencies:

```powershell
pip install -r requirements.txt
```

Run migrations:

```powershell
python manage.py migrate
```

---

## 2. Run Redis Locally

This project uses Memurai as a Redis-compatible server on Windows.

Check the Memurai service:

```powershell
Get-Service Memurai
```

If it is stopped:

```powershell
Start-Service Memurai
```

Check Redis:

```powershell
memurai-cli ping
```

Expected:

```text
PONG
```

If `memurai-cli` is not available in PATH, use:

```powershell
& "C:\Program Files\Memurai\memurai-cli.exe" ping
```

---

## 3. Start Celery Worker

Open a new PowerShell terminal:

```powershell
cd "D:\Job Application Tracker"
.\venv\Scripts\Activate.ps1
celery -A jobtracker worker --loglevel=info --pool=solo
```

> Replace `jobtracker` with your Django project package name if different.

Keep the Celery terminal running.

---

## 4. Run Django Server

Open another PowerShell terminal:

```powershell
cd "D:\Job Application Tracker"
.\venv\Scripts\Activate.ps1
python manage.py runserver
```

Django will run at:

```text
http://127.0.0.1:8000/
```

---

# 5. Postman API Requests

## Authentication

### Get Token

**Method:**

```text
POST
```

**URL:**

```text
http://127.0.0.1:8000/api/token/
```

**Postman → Body → x-www-form-urlencoded**

| Key      | Value         |
| -------- | ------------- |
| username | YOUR_USERNAME |
| password | YOUR_PASSWORD |

Example response:

```json
{
    "token": "YOUR_TOKEN"
}
```

Copy the token and use it for the remaining API requests.

---

## Authorization

For all protected API requests, add this header:

```text
Authorization: Token YOUR_TOKEN
```

---

## 6. List Applications

**Method:**

```text
GET
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/
```

**Header:**

```text
Authorization: Token YOUR_TOKEN
```

---

## 7. Filter Applications by Status

### Interview Applications

**Method:**

```text
GET
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/?status=Interview
```

**Header:**

```text
Authorization: Token YOUR_TOKEN
```

### Applied Applications

```text
http://127.0.0.1:8000/api/applications/?status=Applied
```

---

## 8. Create Application

**Method:**

```text
POST
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/
```

**Headers:**

```text
Authorization: Token YOUR_TOKEN
Content-Type: application/json
```

**Postman → Body → raw → JSON**

```json
{
    "company_name": "ABC Technologies",
    "role": "Python Developer",
    "status": "Applied",
    "applied_date": "2026-09-25",
    "notes": "Applied through LinkedIn"
}
```

The `user` field does not need to be provided because the logged-in user is assigned automatically.

---

## 9. Get Single Application

**Method:**

```text
GET
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/YOUR_APPLICATION_ID/
```

Example:

```text
http://127.0.0.1:8000/api/applications/84b2b905-2f36-4062-b424-a66667358486/
```

**Header:**

```text
Authorization: Token YOUR_TOKEN
```

---

## 10. Update Application

**Method:**

```text
PUT
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/YOUR_APPLICATION_ID/
```

**Headers:**

```text
Authorization: Token YOUR_TOKEN
Content-Type: application/json
```

**Body → raw → JSON**

```json
{
    "company_name": "ABC Technologies",
    "role": "Senior Python Developer",
    "status": "Interview",
    "applied_date": "2026-09-25",
    "notes": "Interview scheduled"
}
```

---

## 11. Partial Update Application

Use PATCH when you only want to update specific fields.

**Method:**

```text
PATCH
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/YOUR_APPLICATION_ID/
```

**Headers:**

```text
Authorization: Token YOUR_TOKEN
Content-Type: application/json
```

**Body → raw → JSON**

```json
{
    "status": "Interview"
}
```

---

## 12. Delete Application

**Method:**

```text
DELETE
```

**URL:**

```text
http://127.0.0.1:8000/api/applications/YOUR_APPLICATION_ID/
```

**Header:**

```text
Authorization: Token YOUR_TOKEN
```

Expected response:

```text
204 No Content
```

---

# API Endpoints Summary

| Method | Endpoint                              | Description                  |
| ------ | ------------------------------------- | ---------------------------- |
| POST   | `/api/token/`                         | Get authentication token     |
| GET    | `/api/applications/`                  | List user's applications     |
| POST   | `/api/applications/`                  | Create application           |
| GET    | `/api/applications/<id>/`             | Get application              |
| PUT    | `/api/applications/<id>/`             | Update application           |
| PATCH  | `/api/applications/<id>/`             | Partially update application |
| DELETE | `/api/applications/<id>/`             | Delete application           |
| GET    | `/api/applications/?status=Interview` | Filter by status             |

---

## 13. User Data Protection

The API only returns applications belonging to the authenticated user.

Authentication is required for application endpoints.

The `user` field is assigned automatically when creating an application.

---

## 14. Running the Project

Run these services in separate terminals:

### Terminal 1 — Memurai

```powershell
Get-Service Memurai
```

### Terminal 2 — Celery

```powershell
cd "D:\Job Application Tracker"
.\venv\Scripts\Activate.ps1
celery -A jobtracker worker --loglevel=info --pool=solo
```

### Terminal 3 — Django

```powershell
cd "D:\Job Application Tracker"
.\venv\Scripts\Activate.ps1
python manage.py runserver
```

Django API:

```text
http://127.0.0.1:8000/api/
```
