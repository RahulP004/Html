from django.core.cache import cache

from rest_framework import viewsets
from rest_framework.response import Response

from .cache_utils import (
    CACHE_TIMEOUT,
    get_applications_cache_key,
)
from .models import JobApplication
from .serializers import JobApplicationSerializer

from django.contrib.auth.decorators import login_required
from django.shortcuts import (
    get_object_or_404,
    redirect,
    render,
)

from .cache_utils import (
    get_dashboard_stats,
    invalidate_user_cache,
)

from .forms import JobApplicationForm


class JobApplicationViewSet(viewsets.ModelViewSet):

    serializer_class = JobApplicationSerializer

    def get_queryset(self):
        return JobApplication.objects.filter(
            user=self.request.user
        ).order_by("-created_at")

    def list(self, request, *args, **kwargs):

        status_filter = request.query_params.get("status")

        if status_filter:

            queryset = self.get_queryset().filter(
                status=status_filter
            )

            serializer = self.get_serializer(
                queryset,
                many=True
            )

            return Response(serializer.data)

        cache_key = get_applications_cache_key(
            request.user.id
        )

        cached_data = cache.get(cache_key)

        if cached_data is not None:

            print("APPLICATION LIST: CACHE HIT")

            return Response(cached_data)

        print("APPLICATION LIST: DATABASE HIT")

        queryset = self.get_queryset()

        serializer = self.get_serializer(
            queryset,
            many=True
        )

        data = list(serializer.data)

        cache.set(
            cache_key,
            data,
            CACHE_TIMEOUT
        )

        return Response(data)

    def perform_create(self, serializer):

        serializer.save(
            user=self.request.user
        )

    def perform_update(self, serializer):

        serializer.save()

    def perform_destroy(self, instance):

        instance.delete()
        

@login_required
def dashboard(request):

    applications = JobApplication.objects.filter(
        user=request.user
    ).order_by("-created_at")

    stats = get_dashboard_stats(
        request.user.id
    )

    context = {
        "applications": applications,
        "stats": stats,
    }

    return render(
        request,
        "tracker/dashboard.html",
        context
    )


@login_required
def application_create(request):

    if request.method == "POST":

        form = JobApplicationForm(
            request.POST
        )

        if form.is_valid():

            application = form.save(
                commit=False
            )

            application.user = request.user

            application.save()

            return redirect("dashboard")

    else:

        form = JobApplicationForm()

    return render(
        request,
        "tracker/application_form.html",
        {
            "form": form,
            "title": "Create Application"
        }
    )


@login_required
def application_edit(request, pk):

    application = get_object_or_404(
        JobApplication,
        pk=pk,
        user=request.user
    )

    if request.method == "POST":

        form = JobApplicationForm(
            request.POST,
            instance=application
        )

        if form.is_valid():

            form.save()

            return redirect("dashboard")

    else:

        form = JobApplicationForm(
            instance=application
        )

    return render(
        request,
        "tracker/application_form.html",
        {
            "form": form,
            "title": "Edit Application"
        }
    )