from django.db import models
import uuid
from django.contrib.auth.models import User


class JobApplication(models.Model):
    staus_type =[
        ("Applied", "Applied"),
        ("Screening", "Screening"),
        ("Interview", "Interview"),
        ("Offer", "Offer"),
        ("Rejected", "Rejected"),
        ("Withdrawn", "Withdrawn"),
    ]
    
    id= models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    user= models.ForeignKey(User,on_delete=models.CASCADE,related_name='job_application')
    company_name=models.CharField(max_length=255,)
    role=models.CharField(max_length=255,)
    status=models.CharField(max_length=10,choices=staus_type,default='Applied')
    applied_date=models.DateField()
    notes=models.TextField(blank=True,null=True)
    created_at=models.DateTimeField(auto_now_add=True,)
    updated_at=models.DateTimeField(auto_now_add=True,)
    
    def __str__(self):
        return f"{self.company_name} - {self.role}"
    
    
class ApplicationStatusLog(models.Model):
    application=models.ForeignKey(JobApplication,on_delete=models.CASCADE,related_name='status_log')
    old_status=models.CharField(max_length=10)
    new_status=models.CharField(max_length=10)
    changed_at=models.DateTimeField(auto_now_add=True,)
    
    def __str__(self):
        return (
            f"{self.application} : "
            f"{self.old_status} → {self.new_status}"
        )
