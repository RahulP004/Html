"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from rest_framework.authtoken.views import obtain_auth_token


urlpatterns = [

    # Django Admin
    path(
        "admin/",
        admin.site.urls
    ),

    # REST API
    path(
        "api/",
        include("tracker.api_urls")
    ),

    # API Token Login
    path(
        "api/token/",
        obtain_auth_token
    ),

    # HTML Dashboard / Application pages
    path(
        "",
        include("tracker.urls")
    ),

    # Django Login / Logout
    path(
        "accounts/",
        include("django.contrib.auth.urls")
    ),
]