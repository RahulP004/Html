from django.db.models.signals import post_delete, post_save, pre_save
from django.dispatch import receiver
from django.db import transaction

from .cache_utils import invalidate_user_cache
from .models import JobApplication
from .tasks import notify_status_change


@receiver(pre_save, sender=JobApplication)
def remember_old_status(
    sender,
    instance,
    **kwargs
):


    if not instance.pk:
        instance._old_status = None
        return

    try:
        old_application = JobApplication.objects.get(
            pk=instance.pk
        )

        instance._old_status = old_application.status

    except JobApplication.DoesNotExist:
        instance._old_status = None


@receiver(post_save, sender=JobApplication)
def job_application_saved(
    sender,
    instance,
    created,
    **kwargs
):

    if instance.user_id:
        invalidate_user_cache(
            instance.user_id
        )
    if created:
        return

    old_status = getattr(
        instance,
        "_old_status",
        None
    )

    new_status = instance.status

    if not old_status:
        return

    if old_status == new_status:
        return

    transaction.on_commit(
        lambda: notify_status_change.delay(
            str(instance.id),
            old_status,
            new_status
        )
    )


@receiver(post_delete, sender=JobApplication)
def job_application_deleted(
    sender,
    instance,
    **kwargs
):

    if instance.user_id:
        invalidate_user_cache(
            instance.user_id
        )