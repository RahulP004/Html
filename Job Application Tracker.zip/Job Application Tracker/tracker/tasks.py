import logging

from celery import shared_task

from .models import ApplicationStatusLog, JobApplication


logger = logging.getLogger(__name__)


@shared_task
def notify_status_change(
    application_id,
    old_status,
    new_status,
):

    application = JobApplication.objects.get(
        id=application_id
    )

    logger.info(
        "[NOTIFICATION] Application at "
        f'"{application.company_name}" moved '
        f"from '{old_status}' → '{new_status}'"
    )

    ApplicationStatusLog.objects.create(
        application=application,
        old_status=old_status,
        new_status=new_status,
    )