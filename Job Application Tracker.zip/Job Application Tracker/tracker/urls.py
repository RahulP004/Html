from django.urls import path

from .views import (
    application_create,
    application_edit,
    dashboard,
)


urlpatterns = [

    path(
        "dashboard/",
        dashboard,
        name="dashboard"
    ),

    path(
        "applications/create/",
        application_create,
        name="application_create"
    ),

    path(
        "applications/<uuid:pk>/edit/",
        application_edit,
        name="application_edit"
    ),
]